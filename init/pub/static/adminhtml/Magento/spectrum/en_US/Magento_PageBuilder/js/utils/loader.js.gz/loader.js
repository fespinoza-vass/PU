/*eslint-disable */
/* jscs:disable */
define([], function () {
  /**
   * Copyright © Magento, Inc. All rights reserved.
   * See COPYING.txt for license details.
   */
  function load(dependencies, factory, onError) {
    require(dependencies, factory, onError);
  }

  return load;
});
//# sourceMappingURL=loader.js.map